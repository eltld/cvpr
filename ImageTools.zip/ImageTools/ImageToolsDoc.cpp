
// ImageToolsDoc.cpp : CImageToolsDoc Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "ImageTools.h"
#endif
#include "FileNewDig.h"
#include "ImageToolsDoc.h"
#include "DibEnhancement.h"
#include "HistogramDlg.h"
#include "DibFilter.h"
#include "GaussianDlg.h"
#include "ArithmeticDlg.h"
#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CImageToolsDoc

IMPLEMENT_DYNCREATE(CImageToolsDoc, CDocument)

BEGIN_MESSAGE_MAP(CImageToolsDoc, CDocument)
	ON_COMMAND(ID_WINDOW_DUPLICATE, &CImageToolsDoc::OnWindowDuplicate)
	ON_COMMAND(ID_EDIT_COPY, &CImageToolsDoc::OnEditCopy)
	
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, &CImageToolsDoc::OnUpdateEditPaste)
	
	ON_COMMAND(ID_IMAVE_INVERSE, &CImageToolsDoc::OnImaveInverse)
	ON_COMMAND(ID_IMAGE_BRIGHTNESS, &CImageToolsDoc::OnImageBrightness)
	ON_COMMAND(ID_IMAGE_CONTRAST, &CImageToolsDoc::OnImageContrast)
	ON_COMMAND(ID_VIEW_HISTOGRAM, &CImageToolsDoc::OnViewHistogram)
	ON_COMMAND(ID_HISTOGRAM_EQUALIZATION, &CImageToolsDoc::OnHistogramEqualization)
	ON_COMMAND(ID_IMAGE_ARITHMETIC, &CImageToolsDoc::OnImageArithmetic)
	ON_COMMAND(ID_BITPLANE_SLICING, &CImageToolsDoc::OnBitplaneSlicing)
	ON_COMMAND(ID_ADD_BITPLANE, &CImageToolsDoc::OnAddBitplane)
	ON_COMMAND(ID_FILTER_MEAN, &CImageToolsDoc::OnFilterMean)
	ON_COMMAND(ID_FILTER_WEIGHTED_MEAN, &CImageToolsDoc::OnFilterWeightedMean)
	ON_COMMAND(ID_FILTER_GAUSSIAN, &CImageToolsDoc::OnFilterGaussian)
END_MESSAGE_MAP()


// CImageToolsDoc ����/�Ҹ�

CImageToolsDoc::CImageToolsDoc()
{
	// TODO: ���⿡ ��ȸ�� ���� �ڵ带 �߰��մϴ�.

}

CImageToolsDoc::~CImageToolsDoc()
{
}

BOOL CImageToolsDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	if (!CDocument::OnNewDocument())
		return FALSE;
	BOOL bSuccess = TRUE;
	
	if (theApp.m_pNewDib == NULL)
	{
		CFileNewDig dig;
		if (dig.DoModal() == IDOK)
		{
			if (dig.m_nType == 0) // Gray Scale Image
				bSuccess = m_Dib.CreateGrayImage(dig.m_nWidth, dig.m_nHeight);
			else //True Color Image
				bSuccess = m_Dib.CreateRGBImage(dig.m_nWidth, dig.m_nHeight);
		}
		else
			bSuccess = FALSE;
	}
	else
	{
		m_Dib.Copy(theApp.m_pNewDib);
		theApp.m_pNewDib = NULL;
	}

	return bSuccess;
}




// CImageToolsDoc serialization

void CImageToolsDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
	}
	else
	{
		// TODO: ���⿡ �ε� �ڵ带 �߰��մϴ�.
	}
}

#ifdef SHARED_HANDLERS

// ����� �׸��� �����մϴ�.
void CImageToolsDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// ������ �����͸� �׸����� �� �ڵ带 �����Ͻʽÿ�.
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �˻� ó���⸦ �����մϴ�.
void CImageToolsDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// ������ �����Ϳ��� �˻� �������� �����մϴ�.
	// ������ �κ��� ";"�� ���еǾ�� �մϴ�.

	// ��: strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CImageToolsDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CImageToolsDoc ����

#ifdef _DEBUG
void CImageToolsDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CImageToolsDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CImageToolsDoc ����


BOOL CImageToolsDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	return m_Dib.Load(lpszPathName); 
}


BOOL CImageToolsDoc::OnSaveDocument(LPCTSTR lpszPathName)
{
	return m_Dib.Save(lpszPathName);
}


void CImageToolsDoc::OnWindowDuplicate()
{
	AfxNewImage(m_Dib);
}


void CImageToolsDoc::OnEditCopy()
{
	if (m_Dib.IsValid())
		m_Dib.CopyToClipboard();
}
						   
void CImageToolsDoc::OnUpdateEditPaste(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(IsClipboardFormatAvailable(CF_DIB));
}



void CImageToolsDoc::OnImaveInverse()
{
	CDib dib = m_Dib;
	DibInverse(dib);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnImageBrightness()
{
	CDib dib = m_Dib;
	DibBrightness(dib,40);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnImageContrast()
{
	CDib dib = m_Dib;
	DibContrast(dib, 40);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnViewHistogram()
{
	CHistogramDlg dlg;
	dlg.SetImage(m_Dib);
	dlg.DoModal();
}


void CImageToolsDoc::OnHistogramEqualization()
{
	CDib dib = m_Dib;
	DibHistEqual(dib);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnImageArithmetic()
{
	CArithmeticDlg dlg;
	if (dlg.DoModal() == IDOK)
	{
		CImageToolsDoc* pDoc1 = (CImageToolsDoc*)dlg.m_pDoc1;
		CImageToolsDoc* pDoc2 = (CImageToolsDoc*)dlg.m_pDoc2;
		
		CDib dib;
		BOOL ret = FALSE;
		
		switch (dlg.m_nFunction)
		{
		case 0:ret = DibAdd(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 1:ret = DibSub(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 2:ret = DibAve(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 3:ret = DibDif(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 4:ret = DibAND(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 5:ret = DibOR(pDoc1->m_Dib, pDoc2->m_Dib, dib); break;
		case 6:ret = DibAddBitPlane(pDoc1->m_Dib, pDoc2->m_Dib,dib); break;
		}
		if (ret)
			AfxNewImage(dib);
		else
			AfxMessageBox(_T("������ ũ�Ⱑ �ٸ��ϴ�"));
	}
}


void CImageToolsDoc::OnBitplaneSlicing()
{
	register int i, j;

	int w = m_Dib.GetWidth();
	int h = m_Dib.GetHeight();

	CDib dib;
	dib.CreateGrayImage(w, h);

	for (i = 0; i < 8; i++)
	{
		DibBitPlane(m_Dib, i, dib);
		AfxNewImage(dib);
	}
}


void CImageToolsDoc::OnAddBitplane()
{
	register int i, j;
	int w = m_Dib.GetWidth();
	int h = m_Dib.GetHeight();
	
}


void CImageToolsDoc::OnFilterMean()
{
	CDib dib = m_Dib;
	DibFilterMean(dib);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnFilterWeightedMean()
{
	CDib dib = m_Dib;
	DibFilterWeightedMean(dib);
	AfxNewImage(dib);
}


void CImageToolsDoc::OnFilterGaussian()
{
	CGaussianDlg dlg;
	if (dlg.DoModal() == IDOK)
	{
		CDib dib = m_Dib;
		DibFilterGaussian(dib, dlg.m_fSigma);
		AfxNewImage(dib);
	}
}
