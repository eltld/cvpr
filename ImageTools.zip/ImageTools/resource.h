//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// ImageTools.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_ImageToolsTYPE              130
#define ID_WINDOW_MANAGER               131
#define ID_VIEW_OUTPUTWND               149
#define IDS_OUTPUT_WND                  157
#define IDI_OUTPUT_WND                  165
#define IDI_OUTPUT_WND_HC               166
#define IDR_OUTPUT_POPUP                182
#define IDS_BUILD_TAB                   300
#define IDS_DEBUG_TAB                   301
#define IDS_FIND_TAB                    302
#define IDS_EDIT_MENU                   306
#define IDD_FILE_NEW                    310
#define IDD_HISTOGRAM                   313
#define IDD_ARITHMETIC                  314
#define IDD_GAUSSIAN                    315
#define IDC_WIDTH                       1000
#define IDC_HEIGHT                      1001
#define IDC_IMAGETYPE                   1002
#define IDC_COMBO1                      1003
#define IDC_COMBO2                      1004
#define IDC_RADIO1                      1005
#define IDC_RADIO2                      1006
#define IDC_RADIO3                      1007
#define IDC_RADIO4                      1008
#define IDC_RADIO5                      1009
#define IDC_RADIO6                      1010
#define IDC_RADIO7                      1011
#define IDC_SIGMA_SLIDER                1012
#define IDC_SIGMA_EDIT                  1013
#define ID_32771                        32771
#define ID_WINDOW_DUPLICATE             32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_VIEW_ZOOM1                   32780
#define ID_VIEW_ZOOM2                   32781
#define ID_VIEW_ZOOM3                   32782
#define ID_VIEW_ZOOM4                   32783
#define ID_CHAPTER6_IMAVEINVERSE        32784
#define ID_IMAVE_INVERSE                32785
#define ID_CHAPTER6_IMAGEBRIGHTNESS     32786
#define ID_IMAVEINVERSE                 32787
#define ID_IMAGEINVERSE                 32788
#define ID_IMAVE_BRIGHTNESS             32789
#define ID_IMAGE_BRIGHTNESS             32790
#define ID_IMAGE_INVERSE                32791
#define ID_CHAPTER6_IMAGECONTRAST       32792
#define ID_IMAGE_CONTRAST               32793
#define ID_CHAPTER6_IMAGEHISTOGRAM      32794
#define ID_IMAGE_HISTOGRAM              32795
#define ID_VIEW_HISTOGRAM               32796
#define ID_CHAPTER6_HISTOGRAMEQUALIZATION 32797
#define ID_HISTOGRAM_EQUALIZATION       32798
#define ID_CHAPTER7_IMAGEPLUS           32799
#define ID_CHAPTER7_SUBOP               32800
#define ID_CHAPTER7_AVEOP               32801
#define ID_CHAPTER7_ARITHEMETIC         32802
#define ID_ARITHMETIC                   32803
#define ID_IMAGE_ARITHMETIC             32804
#define ID_CHAPTER7_BITPLANE            32805
#define ID_BITPLANE_SLICING             32806
#define ID_CHAPTER7_ADDBITPLANE         32807
#define ID_ADD_BITPLANE                 32808
#define ID_32809                        32809
#define ID_WINDOW_CLOSEALL              32810
#define ID_CHAPTER8_MEANVALUEFILTER     32811
#define ID_CHAPTER8_WEIGHTEDMEANVALUEFILTER 32812
#define ID_CHAPTER8_GAUSSIANFILTER      32813
#define ID_FILTER_MEAN                  32814
#define ID_FILTER_WEIGHTED_MEAN         32815
#define ID_FILTER_GAUSSIAN              32816

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32817
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
