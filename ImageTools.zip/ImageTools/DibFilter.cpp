#include "stdafx.h"
#include "Dib.h"
#include "DibFilter.h"
#include <math.h>

const double PI = 3.14159265358979323846;
void DibFilterGaussian(CDib& dib, double sigma)
{
	register int i, j, k , x;

	int w = dib.GetWidth();
	int h = dib.GetHeight();


	BYTE** ptr = dib.GetPtr();

	//1���� ����þ� ����ũ ����

	int dim = (int)max(3.0, 2 * 4 * sigma + 1.0);
	if (dim % 2 == 0) 
		dim++;//1���� ����þ� ����ũ�� Ȧ������ ����
	int dim2 = (int)dim / 2;

	double* pMask = new double[dim];
	for (i = 0; i < dim; i++)
	{
		x = i - dim2;
		pMask[i] = exp(-(x*x) / (2 * sigma*sigma)) / (sqrt(2 * PI)*sigma);
	}
	/*�ӽ� ���� �޸� ���� �Ҵ�*/
	double** buf = new double*[h];
	for (i = 0; i < h; i++)
	{
		buf[i] = new double[w];
		memset(buf[i], 0, sizeof(double)*w);
	}
	/*���� ���� convolution*/
	double sum1, sum2;

	for (i = 0; i < w; i++)
		for (j = 0; j < h; j++)
		{
			sum1 = sum2 = 0.0;

			for (k = 0; k < dim; k++)
			{
				x = k - dim2 + j;

				if (x >= 0 && x < h)
				{
					sum1 += pMask[k];
					sum2 += (pMask[k] * ptr[x][i]);
				}
			}
			buf[j][i] = (sum2 / sum1);
		}
	/*���� ���� convolution*/

	for (j = 0; j < h; j++)
		for (i = 0; i < w; i++)
		{
			sum1 = sum2 = 0.0;
			for (k = 0; k < dim; k++)
			{
				x = k - dim2 + i;
				if (x >= 0 && x < w)
				{
					sum1 += pMask[k];
					sum2 += (pMask[k] * buf[j][x]);
				}
			}
			ptr[j][i] = (BYTE)limit(sum2 / sum1);
		}
	/*���� �Ҵ��ߴ� �޸� ���� ����*/
	delete[] pMask;

	for (i = 0; i < h; i++)
		delete[] buf[i];
	delete[] buf;

}
void DibFilterWeightedMean(CDib& dib)
{
	register int i, j;
	
	int w = dib.GetWidth();
	int h = dib.GetHeight();

	CDib cpy = dib;

	BYTE** ptr1 = dib.GetPtr();
	BYTE** ptr2 = cpy.GetPtr();

	int temp;

	for (j = 1; j < h - 1; j++)
		for (i = 1; i < w - 1; i++)
		{
			temp = ptr2[j - 1][i - 1] + 2*ptr2[j - 1][i] + ptr2[j - 1][i + 1] + 2*ptr2[j][i - 1] + 4*ptr2[j][i] + 2*ptr2[j][i + 1] + ptr2[j + 1][i - 1] + 2*ptr2[j + 1][i] + ptr2[j + 1][i + 1];
			ptr1[j][i] = (BYTE)limit(temp / 16. + 0.5);
		}
}
void DibFilterMean(CDib& dib)
{
	register int i, j;

	int w = dib.GetWidth();
	int h = dib.GetHeight();

	CDib cpy = dib;

	BYTE** ptr1 = dib.GetPtr();
	BYTE** ptr2 = cpy.GetPtr(); 

	int temp;

	for (j = 1; j < h - 1; j++)
		for (i = 1; i < w - 1; i++)
		{
			temp = ptr2[j - 1][i - 1] + ptr2[j - 1][i] + ptr2[j - 1][i+ 1] + ptr2[j][i - 1] + ptr2[j][i] + ptr2[j][i + 1] + ptr2[j + 1][i - 1] + ptr2[j + 1][i] + ptr2[j + 1][i + 1];
			ptr1[j][i] = (BYTE)limit(temp / 9. + 0.5);
		}

}